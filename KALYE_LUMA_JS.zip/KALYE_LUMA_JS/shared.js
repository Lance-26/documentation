const STORAGE_KEY = "kalye_luma_3_modules_data_v1";
const SESSION_KEY = "kalye_luma_session_v1";
