const logoutBtn = document.getElementById("logoutBtn");
if(logoutBtn){ logoutBtn.addEventListener("click", function(){ SESSION = null; sessionStorage.removeItem(SESSION_KEY); document.getElementById("app").classList.remove("active"); document.getElementById("loginScreen").style.display = "flex"; document.getElementById("loginForm").reset(); }); }
